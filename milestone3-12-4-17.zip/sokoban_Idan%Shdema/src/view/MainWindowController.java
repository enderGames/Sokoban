package view;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Observable;
import java.util.ResourceBundle;

import commons.Level;
import commons.SignBoard;
import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * The GUI controller, it's a view implementation, observed by
 * SokobanController.<br>
 * Contains methods for the menu: loading, saving and exiting.<br>
 * Exits in the right order and closes everything that's open in the GUI.
 * 
 * @author Eon
 *
 */
public class MainWindowController extends Observable implements Initializable, View {
	private Stage primaryStage;

	private char[][] sokobanData;
	private HashMap<String, String> keyMap;
	private boolean loaded;
	private MediaPlayer mp;
//	private Scene otherScene;

	@FXML
	SokobanDisplayer sokobanDisplayer;

	@FXML
	Label clock;

	@FXML
	Label steps;

	@FXML
	TextField fName;
	
	@FXML
	TextField lName;
	
	@FXML
	TextField Iduser;
	
	// is called when the class is made, and we can also call it again in other
	// places
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		String path = "./resources/music.mp3";
		Media media = new Media(new File(path).toURI().toString());
		mp = new MediaPlayer(media);

		loaded = false;

		sokobanDisplayer.setSokobanData(sokobanData); // controller sends
														// signboard

		sokobanDisplayer.setFocusTraversable(true);
		sokobanDisplayer.setOnKeyPressed(new EventHandler<KeyEvent>() {

			@Override
			public void handle(KeyEvent event) {
				String direction = "";
				if (event.getCode().getName().equals(keyMap.get("up"))) {
					direction = "up";
				} else if (event.getCode().getName().equals(keyMap.get("down"))) {
					direction = "down";
				} else if (event.getCode().getName().equals(keyMap.get("right"))) {
					sokobanDisplayer.setCharFileName(sokobanDisplayer.getBobRightFileName());
					direction = "right";
				} else if (event.getCode().getName().equals(keyMap.get("left"))) {
					sokobanDisplayer.setCharFileName(sokobanDisplayer.getBobLeftFileName());
					direction = "left";
				}

				if (!direction.equals("")) {
					LinkedList<String> params = new LinkedList<String>();
					params.add("Move");
					params.add(direction);

					setChanged();
					notifyObservers(params);
				}
			}
		});
	}

	public void openFile() {
		FileChooser fc = new FileChooser();
		fc.setTitle("Open Sokoban file"); // title for the file dialog
		fc.setInitialDirectory(new File("./")); // the directory to open
		fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("XML Files", "*.xml")); // file
																								// types
																								// to
																								// choose
																								// from
		File chosen = fc.showOpenDialog(primaryStage); // return main window

		LinkedList<String> params = new LinkedList<String>();
		params.add("Load");
		params.add(chosen.getName());

		setChanged();
		notifyObservers(params);

		// load music
		if (mp != null)
			mp.stop();

		mp.setAutoPlay(true);
		mp.play();

		// if loaded correctly - display
		LinkedList<String> params2 = new LinkedList<String>();
		params2.add("Display");

		setChanged();
		notifyObservers(params2);

		loaded = true;
	}

	public void saveFile() {

		if (!loaded) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("WARNING!!!");
			alert.setHeaderText("Load a level first!");
			alert.setContentText("Cannot save.");

			alert.showAndWait();
		} else {
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Save current level as"); // title for the file
															// dialog
			fileChooser.setInitialDirectory(new File("./")); // the directory to
																// open
			// Set extension filter
			FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("XML file", "*.xml");
			fileChooser.getExtensionFilters().add(extFilter);

			// Show save file dialog
			File file = fileChooser.showSaveDialog(primaryStage);
			LinkedList<String> params = new LinkedList<String>();
			params.add("Save");
			params.add(file.getName());

			setChanged();
			notifyObservers(params);
		}

	}

	public void exitGame() {
		LinkedList<String> params = new LinkedList<String>();
		params.add("Exit");

		setChanged();
		notifyObservers(params);
		if (loaded) {
			mp.dispose();
		}
		exitApplication();
	}

	public void setStage(Stage primaryStage) {
		this.primaryStage = primaryStage;
	}

	@Override
	public void displayMessage(String msg) {
		if (msg.equals("notLoaded")) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("WARNING!!!");
			alert.setHeaderText("Load a level first!");
			alert.setContentText("Please load a level.");

			alert.showAndWait();
		}

		else if (msg.equals("Saved")) {
			Platform.runLater(new Runnable() { // move to JavaFX thread

				@Override
				public void run() {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Level saved");
					alert.setHeaderText("Level saved successfully!");

					alert.showAndWait();
				}
			});
		}

		else if (msg.equals("noCommand")) {
			Platform.runLater(new Runnable() { // move to JavaFX thread

			@Override
			public void run() {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("WARNING!!!");
				alert.setHeaderText("Command not recognized.");
	
				alert.showAndWait();
				}
			});
		}
		else if (msg.equals("WIN")) {


			Platform.runLater(new Runnable() { // move to JavaFX thread

				@Override
				public void run() {
					FXMLLoader loader = new FXMLLoader();
					try {
						Pane details = loader.load(getClass().getResource("/Details.fxml").openStream());
						Scene detailsScene = new Scene(details, 800, 800);
						Stage detailsStage = new Stage();
						detailsStage.setScene(detailsScene);
						detailsStage.show();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					
					
//					primaryStage.setScene(otherScene);
					
//					Alert alert = new Alert(AlertType.INFORMATION);
//					alert.setTitle("YOU WON");
//					alert.setHeaderText("Good game!");
//
//					alert.showAndWait();
//
//					// enter details window
				}
			});
		}
		
//		LinkedList<String> params = new LinkedList<String>();
//		params.add("Details"); // so the controller knows it's the user details 
//		params.add("jgjjjj");
//		params.add("tdtyht");
//		params.add("71287"); // casting to int when receive
//		setChanged();
//		notifyObservers(params);
	}

	@Override
	public void display(Level l) {
		sokobanData = new SignBoard(l).getSignBoard(); // init sokobanData with
														// signboard from l
		sokobanDisplayer.setSokobanData(sokobanData);
		sokobanDisplayer.redraw();
	}

	@Override
	public void exit(Level l) {
		Platform.exit();
	}

	@FXML
	public void exitApplication() {
		Platform.exit();
	}

	public HashMap<String, String> getKeyMap() {
		return keyMap;
	}

	public void setKeyMap(HashMap<String, String> keyMap) {
		this.keyMap = keyMap;
	}

	@Override
	public void bindTime(StringProperty time) {
		this.clock.textProperty().bind(time);
	}

	@Override
	public void bindSteps(IntegerProperty steps) {
		this.steps.textProperty().bind(steps.asString());
	}

	@Override
	public void start() {
		// TODO Auto-generated method stub

	}

//	public void setScene(Scene detailsScene) {
//		otherScene = detailsScene;
//	}
	public void setDetails(){
		LinkedList<String> params = new LinkedList<String>();
		params.add("Details"); // so the controller knows it's the user details 
		params.add(fName.getText());
		params.add(lName.getText());
		params.add(Iduser.getText()); // casting to int when receive
		setChanged();
		notifyObservers(params);
	}
}
