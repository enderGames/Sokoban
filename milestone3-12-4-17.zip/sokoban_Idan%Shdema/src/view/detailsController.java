package view;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;

public class detailsController implements Initializable {

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}

}
