package model.data;

/**
 * Item of type box.
 * @author ����
 *
 */
public class Box extends MovableItem {

	Box(int x, int y) {
		super(x, y, "Box");
	}


}
