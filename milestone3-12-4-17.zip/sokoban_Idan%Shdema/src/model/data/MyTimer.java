package model.data;

import java.io.PrintWriter;
import java.io.Serializable;
/**
 * A clock that count time from the loading of a level.
 * @author Eon
 *
 */
public class MyTimer implements Serializable {
	
	private int sec,min,hour;

	public MyTimer()
	{
		sec = 0;
		min = 0;
		hour = 0;
	}
	
	public MyTimer(MyTimer t)
	{
		this.sec = t.sec;
		this.min = t.min;
		this.hour = t.hour;
	}
	
	@Override
	public String toString()
	{
		String timeStr = "";
		
		if (hour<10)
			timeStr += ("Time: 0" + hour);
		else
			timeStr += ("Time: " + hour);
		if (min<10)
			timeStr += (":0" + min);
		else
			timeStr += (":" + min);
		if (sec<10)
			timeStr += (":0" + sec);
		else
			timeStr += (":" + sec);
		
		return timeStr;
	}
	
	public void printTime(PrintWriter out)
	{
		out.println(toString());
	}
	
	//gets and sets
	public int getSec() {
		return sec;
	}

	public void setSec(int sec) {
		this.sec = sec;
	}

	public int getMin() {
		return min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getHour() {
		return hour;
	}

	public void setHour(int hour) {
		this.hour = hour;
	}
}
