package model.data;

/**
 * Item of type Character.
 * @author ����
 *
 */
public class Character extends MovableItem {
	Character(int x,int y){
		super(x,y,"Character");
	}
}
