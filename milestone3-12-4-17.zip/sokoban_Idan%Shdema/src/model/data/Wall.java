package model.data;

/**
 * A wall item.
 * @author ����
 *
 */
public class Wall extends Item {

	Wall(int x, int y) {
		super(x, y, "Wall");
	}

}
