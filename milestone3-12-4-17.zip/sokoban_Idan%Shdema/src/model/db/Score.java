package model.db;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;

@Entity(name = "Scoreboard")
public class Score {

	@EmbeddedId
	private ScorePK key;
	@Column(name = "Steps")
	private int steps;
	@Column(name = "Time")
	private String time;

	public Score() {
		this.key= new ScorePK();
	}

	public Score(int UserID, int LevelID, int steps, String time) {
		this.key = new ScorePK(UserID, LevelID);
		this.steps = steps;
		this.time = time;
	}
	
	public int getUserID() {
		return key.getUserID();
	}
	
	public int getLevelID() {
		return key.getLevelID();
	}

	public int getSteps() {
		return steps;
	}

	public void setSteps(int steps) {
		this.steps = steps;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

}
